addappid(1250410) -- Microsoft Flight Simulator (2020) 40th Anniversary Edition
addappid(1250411,0,"dbf9d5a5cae7eab44d452bfe53856e4b08b448ac7c224124316ca8cf3f91b3a8") -- Depot 1 (1250411_4615252933050935740.manifest)
addappid(228988,0,"1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- Depot 2 (228988_6645201662696499616.manifest)

-- Made with love by LightningFast⚡💜